import { useState } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { closedRiskColumns } from "@/components/tables/closed-risk-columns";
import { closedRiskItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Download, Upload, Filter, FileText } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function ClosedRiskPage() {
  const [data] = useState(closedRiskItems);

  // Count items by approval
  const approvedCount = data.filter(item => item.approvalFlag).length;
  const pendingCount = data.filter(item => !item.approvalFlag).length;
  const reviewedByCisoCount = data.filter(item => item.reviewedByCiso).length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Closed Risk Register</h2>
          <p className="text-muted-foreground">
            Track and manage closed risks and their documentation status.
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            <span>Import</span>
          </Button>
          <Button className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span>New Closure Form</span>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Approved
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100 text-lg py-1 px-2">
                {approvedCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((approvedCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pending Approval
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 text-lg py-1 px-2">
                {pendingCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((pendingCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              CISO Reviewed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 text-lg py-1 px-2">
                {reviewedByCisoCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((reviewedByCisoCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Closed Risk Register</CardTitle>
          <CardDescription>
            A list of all risks that have been formally closed.
          </CardDescription>
        </CardHeader>
        <DataTable
          columns={closedRiskColumns}
          data={data}
          searchPlaceholder="Search closed risks..."
        />
      </Card>
    </div>
  );
}