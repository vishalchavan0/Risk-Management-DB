import { useState } from "react";
import { DataTable } from "@/components/tables/DataTable";
import { riskAcceptanceColumns } from "@/components/tables/risk-acceptance-columns";
import { riskAcceptanceItems } from "@/data/sampleData";
import { Button } from "@/components/ui/button";
import { Plus, Download, Upload, Filter } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function RiskAcceptancePage() {
  const [data] = useState(riskAcceptanceItems);

  // Count items by status
  const inPlaceCount = data.filter(item => item.status === "In place").length;
  const inProgressCount = data.filter(item => item.status === "In Progress").length;
  const expiredCount = data.filter(item => item.status === "Expired").length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Risk Acceptance</h2>
          <p className="text-muted-foreground">
            Track and manage accepted risks and their documentation status.
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            <span>Import</span>
          </Button>
          <Button className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            <span>New Risk Acceptance</span>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              In Place
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100 text-lg py-1 px-2">
                {inPlaceCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((inPlaceCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              In Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 text-lg py-1 px-2">
                {inProgressCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((inProgressCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Expired
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge className="bg-red-100 text-red-800 hover:bg-red-100 text-lg py-1 px-2">
                {expiredCount}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {((expiredCount / data.length) * 100).toFixed(0)}% of total
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Risk Acceptance Register</CardTitle>
          <CardDescription>
            A list of all risks that have been formally accepted by the business.
          </CardDescription>
        </CardHeader>
        <DataTable
          columns={riskAcceptanceColumns}
          data={data}
          searchPlaceholder="Search accepted risks..."
        />
      </Card>
    </div>
  );
}