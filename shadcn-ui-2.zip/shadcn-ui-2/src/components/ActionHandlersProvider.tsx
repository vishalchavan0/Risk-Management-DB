import { createContext, useContext, useEffect, ReactNode } from 'react';
import { ClosedRiskItem } from '@/types';

interface ActionHandlers {
  viewDetails?: (risk: ClosedRiskItem) => void;
  editRisk?: (risk: ClosedRiskItem) => void;
  deleteRisk?: (risk: ClosedRiskItem) => void;
  viewAuditTrail?: (risk: ClosedRiskItem) => void;
  changeStatus?: (risk: ClosedRiskItem, status: string) => void;
}

const ActionHandlersContext = createContext<ActionHandlers>({});

export const useActionHandlers = () => useContext(ActionHandlersContext);

interface ActionHandlersProviderProps {
  children: ReactNode;
  handlers: ActionHandlers;
}

export function ActionHandlersProvider({ children, handlers }: ActionHandlersProviderProps) {
  // Register event handlers globally for the demo
  // In a real app, you'd use context or props instead of the window object
  useEffect(() => {
    if (handlers.viewDetails) {
      (window as any).__viewDetailsHandler = handlers.viewDetails;
    }
    if (handlers.editRisk) {
      (window as any).__editRiskHandler = handlers.editRisk;
    }
    if (handlers.deleteRisk) {
      (window as any).__deleteRiskHandler = handlers.deleteRisk;
    }
    if (handlers.viewAuditTrail) {
      (window as any).__viewAuditTrailHandler = handlers.viewAuditTrail;
    }
    if (handlers.changeStatus) {
      (window as any).__changeStatusHandler = handlers.changeStatus;
    }

    return () => {
      // Cleanup
      delete (window as any).__viewDetailsHandler;
      delete (window as any).__editRiskHandler;
      delete (window as any).__deleteRiskHandler;
      delete (window as any).__viewAuditTrailHandler;
      delete (window as any).__changeStatusHandler;
    };
  }, [handlers]);

  // Also set up actual event listeners for more proper implementations
  useEffect(() => {
    const viewDetailsHandler = (e: Event) => {
      if (handlers.viewDetails && e instanceof CustomEvent) {
        handlers.viewDetails(e.detail);
      }
    };
    
    const editRiskHandler = (e: Event) => {
      if (handlers.editRisk && e instanceof CustomEvent) {
        handlers.editRisk(e.detail);
      }
    };
    
    const deleteRiskHandler = (e: Event) => {
      if (handlers.deleteRisk && e instanceof CustomEvent) {
        handlers.deleteRisk(e.detail);
      }
    };
    
    const viewAuditTrailHandler = (e: Event) => {
      if (handlers.viewAuditTrail && e instanceof CustomEvent) {
        handlers.viewAuditTrail(e.detail);
      }
    };
    
    const changeStatusHandler = (e: Event) => {
      if (handlers.changeStatus && e instanceof CustomEvent) {
        const { risk, status } = e.detail;
        handlers.changeStatus(risk, status);
      }
    };

    document.addEventListener('viewDetails', viewDetailsHandler);
    document.addEventListener('editRisk', editRiskHandler);
    document.addEventListener('deleteRisk', deleteRiskHandler);
    document.addEventListener('viewAuditTrail', viewAuditTrailHandler);
    document.addEventListener('changeStatus', changeStatusHandler);

    return () => {
      document.removeEventListener('viewDetails', viewDetailsHandler);
      document.removeEventListener('editRisk', editRiskHandler);
      document.removeEventListener('deleteRisk', deleteRiskHandler);
      document.removeEventListener('viewAuditTrail', viewAuditTrailHandler);
      document.removeEventListener('changeStatus', changeStatusHandler);
    };
  }, [handlers]);

  return (
    <ActionHandlersContext.Provider value={handlers}>
      {children}
    </ActionHandlersContext.Provider>
  );
}