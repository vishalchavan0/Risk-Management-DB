import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Table,
  CheckSquare,
  Archive,
  Menu,
  LogOut,
  Shield
} from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";

interface SidebarItem {
  icon: React.ReactNode;
  title: string;
  path: string;
}

const sidebarItems: SidebarItem[] = [
  {
    icon: <LayoutDashboard className="h-5 w-5" />,
    title: "Dashboard",
    path: "/"
  },
  {
    icon: <Table className="h-5 w-5" />,
    title: "Risk Data Sheet",
    path: "/risk-data"
  },
  {
    icon: <CheckSquare className="h-5 w-5" />,
    title: "Risk Acceptance",
    path: "/risk-acceptance"
  },
  {
    icon: <Archive className="h-5 w-5" />,
    title: "Closed Risk Register",
    path: "/closed-risk"
  }
];

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <div
        className={cn(
          "bg-secondary text-secondary-foreground flex flex-col transition-all duration-300 h-full border-r",
          collapsed ? "w-16" : "w-64"
        )}
      >
        {/* Logo and collapse button */}
        <div className="flex items-center justify-between p-4 border-b">
          {!collapsed && (
            <div className="flex items-center gap-2">
              <Shield className="h-6 w-6 text-primary" />
              <span className="font-bold text-lg">RiskManager</span>
            </div>
          )}
          {collapsed && <Shield className="h-6 w-6 text-primary mx-auto" />}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(!collapsed)}
            className="ml-auto"
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4">
          <ul className="space-y-1 px-2">
            {sidebarItems.map((item) => (
              <li key={item.path}>
                <Button
                  variant={location.pathname === item.path ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start",
                    location.pathname === item.path
                      ? "bg-primary/10 hover:bg-primary/20"
                      : ""
                  )}
                  onClick={() => navigate(item.path)}
                >
                  {item.icon}
                  {!collapsed && <span className="ml-3">{item.title}</span>}
                </Button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Logout */}
        <div className="p-4 border-t">
          <Button variant="ghost" className="w-full justify-start">
            <LogOut className="h-5 w-5" />
            {!collapsed && <span className="ml-3">Logout</span>}
          </Button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-auto bg-background">
        <header className="sticky top-0 z-10 bg-background border-b p-4">
          <h1 className="text-2xl font-bold">
            Risk Management - UltraTechNet
          </h1>
        </header>
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
}