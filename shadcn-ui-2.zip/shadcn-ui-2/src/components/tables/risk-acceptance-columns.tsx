import { ColumnDef } from "@tanstack/react-table";
import { RiskAcceptanceItem } from "@/types";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, MoreHorizontal, Check, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export const riskAcceptanceColumns: ColumnDef<RiskAcceptanceItem>[] = [
  {
    accessorKey: "srNo",
    header: "SR NO",
  },
  {
    accessorKey: "number",
    header: "Number",
  },
  {
    accessorKey: "title",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Title
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-medium">{row.getValue("title")}</div>,
  },
  {
    accessorKey: "raFrNoOrCve",
    header: "RA FR NO/CVE",
  },
  {
    accessorKey: "raAcceptanceDate",
    header: "RA Acceptance Date",
  },
  {
    accessorKey: "raEndDate",
    header: "RA End Date",
  },
  {
    accessorKey: "raDocumentationStatus",
    header: "RA Documentation Status",
    cell: ({ row }) => {
      const status = row.getValue("raDocumentationStatus") as string;
      return (
        <Badge
          variant="outline"
          className={
            status === "Completed"
              ? "bg-green-50 text-green-600 border-green-300"
              : "bg-amber-50 text-amber-600 border-amber-300"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "department",
    header: "Department",
  },
  {
    accessorKey: "riskLevel",
    header: "Risk Level",
    cell: ({ row }) => {
      const level = row.getValue("riskLevel") as string;
      return (
        <Badge
          className={
            level === "High"
              ? "bg-red-100 text-red-800 hover:bg-red-100"
              : level === "Moderate"
                ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
                : "bg-green-100 text-green-800 hover:bg-green-100"
          }
        >
          {level}
        </Badge>
      );
    },
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return (
        <Badge
          variant="outline"
          className={
            status === "In place"
              ? "bg-green-50 text-green-600 border-green-300"
              : status === "In Progress"
                ? "bg-blue-50 text-blue-600 border-blue-300"
                : "bg-red-50 text-red-600 border-red-300"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "riskOwner",
    header: "Risk Owner",
  },
  {
    accessorKey: "blockade",
    header: "Blockade",
    cell: ({ row }) => {
      const blockade = row.getValue("blockade") as boolean;
      return blockade ? (
        <Check className="h-4 w-4 text-green-500" />
      ) : (
        <X className="h-4 w-4 text-red-500" />
      );
    },
  },
  {
    accessorKey: "addedInFair",
    header: "Added in FAIR",
    cell: ({ row }) => {
      const addedInFair = row.getValue("addedInFair") as boolean;
      return addedInFair ? (
        <Check className="h-4 w-4 text-green-500" />
      ) : (
        <X className="h-4 w-4 text-red-500" />
      );
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const risk = row.original;

      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => navigator.clipboard.writeText(risk.id)}>
              Copy ID
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>View Details</DropdownMenuItem>
            <DropdownMenuItem>Edit</DropdownMenuItem>
            <DropdownMenuItem>Update Status</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];