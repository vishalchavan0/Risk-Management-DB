import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { ClosedRiskItem } from "@/types";

// Form schema for validation
const formSchema = z.object({
  riskNumber: z.string().min(1, { message: "Risk number is required" }),
  riskFrNumber: z.string().min(1, { message: "FR number is required" }),
  riskTitle: z.string().min(1, { message: "Risk title is required" }),
  riskClosureDate: z.string().min(1, { message: "Risk closure date is required" }),
  riskOwner: z.string().min(1, { message: "Risk owner is required" }),
  riskClosureEvidenceComments: z.string().min(1, { message: "Evidence comments are required" }),
  reviewedByCiso: z.boolean().default(false),
  approvalFlag: z.boolean().default(false),
  status: z.string().min(1, { message: "Status is required" }),
  approvalDate: z.string().optional(),
  rafFiled: z.boolean().default(false),
});

interface RiskClosureDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  risk?: ClosedRiskItem; // For editing an existing risk
  onSubmit: (values: Partial<ClosedRiskItem>) => void;
  mode: 'create' | 'edit';
}

export function RiskClosureDialog({ open, onOpenChange, risk, onSubmit, mode }: RiskClosureDialogProps) {
  // Initialize form with provided risk data or defaults
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      riskNumber: risk?.riskNumber || "",
      riskFrNumber: risk?.riskFrNumber || "",
      riskTitle: risk?.riskTitle || "",
      riskClosureDate: risk?.riskClosureDate || new Date().toISOString().split('T')[0],
      riskOwner: risk?.riskOwner || "",
      riskClosureEvidenceComments: risk?.riskClosureEvidenceComments || "",
      reviewedByCiso: risk?.reviewedByCiso || false,
      approvalFlag: risk?.approvalFlag || false,
      status: risk?.status || "Pending Approval",
      approvalDate: risk?.approvalDate || "",
      rafFiled: risk?.rafFiled || false,
    },
  });

  // Reset form when dialog opens/closes or risk changes
  useState(() => {
    if (open && risk) {
      form.reset({
        riskNumber: risk.riskNumber,
        riskFrNumber: risk.riskFrNumber,
        riskTitle: risk.riskTitle,
        riskClosureDate: risk.riskClosureDate,
        riskOwner: risk.riskOwner,
        riskClosureEvidenceComments: risk.riskClosureEvidenceComments,
        reviewedByCiso: risk.reviewedByCiso,
        approvalFlag: risk.approvalFlag,
        status: risk.status,
        approvalDate: risk.approvalDate,
        rafFiled: risk.rafFiled,
      });
    }
  });

  const handleSubmit = (values: z.infer<typeof formSchema>) => {
    // Process form values
    onSubmit({
      ...values,
      // Include any additional fields that need to be preserved but aren't in the form
      id: risk?.id || `risk-${Date.now()}`,
      timestamp: risk?.timestamp || new Date().toISOString(),
      emailAddress: risk?.emailAddress || "current-user@example.com", // In a real app, get from auth context
      riskEvidence: risk?.riskEvidence || "", // Would be handled by file upload in a real app
    });

    // Show success toast
    toast.success(mode === 'create' ? "Risk closure created successfully" : "Risk closure updated successfully");
    
    // Close dialog
    onOpenChange(false);
  };

  const title = mode === 'create' ? "Create Risk Closure" : "Edit Risk Closure";
  const description = mode === 'create' 
    ? "Complete the form to create a new risk closure entry."
    : "Update the risk closure information.";
  const submitButtonText = mode === 'create' ? "Create" : "Update";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="riskNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Number *</FormLabel>
                    <FormControl>
                      <Input placeholder="RSK-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="riskFrNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk FR Number *</FormLabel>
                    <FormControl>
                      <Input placeholder="FR-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="riskTitle"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Risk Title *</FormLabel>
                  <FormControl>
                    <Input placeholder="Risk Title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="riskOwner"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Owner *</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="riskClosureDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Closure Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="riskClosureEvidenceComments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Evidence Comments *</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Provide details about the risk closure evidence"
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* File upload would be here in a real app */}
            <div className="border border-dashed border-gray-300 rounded-lg p-4">
              <p className="text-sm text-gray-500 text-center">
                Drag and drop evidence files here or click to upload
                <br />
                <span className="text-xs">(PDF, DOC, PNG, JPG up to 10MB)</span>
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="reviewedByCiso"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel>Reviewed by CISO</FormLabel>
                      <FormDescription>
                        Has this closure been reviewed by CISO?
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="approvalFlag"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel>Approved</FormLabel>
                      <FormDescription>
                        Has this closure been approved?
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status *</FormLabel>
                    <FormControl>
                      <Input value={field.value} onChange={field.onChange} readOnly />
                    </FormControl>
                    <FormDescription>
                      Status is automatically determined by approval state
                    </FormDescription>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="approvalDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Approval Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="rafFiled"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>RAF Filed</FormLabel>
                    <FormDescription>
                      Has the Risk Acceptance Form been filed?
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit">{submitButtonText}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}